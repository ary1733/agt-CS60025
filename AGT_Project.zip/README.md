"# agt-CS60025" 
try to run directly or use conda to install dependencies.(numpy and matplotlib)

to install dependency run this
- conda env create --file environment.yml
then activate the environment using
- conda activate agttest
Or use the following pip command

- pip install -r requirements.txt


After installing the libraries use the Simulation.ipynb jupyter Notebook, 
An equivalent python script is also present Simulation.py which can be executed using 
- make run
or python Simulation.py